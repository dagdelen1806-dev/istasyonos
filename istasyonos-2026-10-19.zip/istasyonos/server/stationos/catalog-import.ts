import { createHash, randomUUID } from "node:crypto";
import type { Express } from "express";
import type { PoolConnection } from "mysql2/promise";
import type { MarketPost } from "./market-route-types";
import type { Services, Row } from "./market-pos";
import { execute, first, rows, withTransaction } from "./db";
import { requireId, requireString } from "./domain";
import { integer } from "./market-accounting-domain";
import { fail, type StationRole } from "./types";
import {
  parseCatalog,
  type CatalogPreview,
  type CatalogHistory,
} from "../../shared/catalog-import";
const READ: StationRole[] = ["OWNER", "MANAGER", "ACCOUNTANT"],
  WRITE: StationRole[] = ["OWNER", "MANAGER"];
const hash = (value: unknown) =>
  createHash("sha256")
    .update(typeof value === "string" ? value : JSON.stringify(value))
    .digest("hex");
const key = (s: string) =>
  s.normalize("NFD").replace(/\p{M}/gu, "").toUpperCase();
async function preview(
  c: PoolConnection,
  station: string,
  text: unknown,
  locked = false
): Promise<CatalogPreview> {
  let parsed;
  try {
    parsed = parseCatalog(text as string);
  } catch (e) {
    fail("INVALID_CATALOG", (e as Error).message);
  }
  const sourceHash = hash(text),
    prior = await first<Row>(
      c,
      "SELECT id FROM st_catalog_imports WHERE station_id=? AND source_hash=?"+(locked?' FOR UPDATE':''),
      [station, sourceHash]
    ),
    existing = await rows<Row[]>(
      c,
      "SELECT id,catalog_code FROM st_products WHERE station_id=? ORDER BY id"+(locked?' FOR UPDATE':''),
      [station]
    ),
    aliases = await rows<Row[]>(
      c,
      "SELECT barcode,product_id FROM st_product_barcodes WHERE station_id=? ORDER BY barcode"+(locked?' FOR UPDATE':''),
      [station]
    );
  const byCode = new Map(
      existing
        .filter(p => p.catalog_code !== null)
        .map(p => [key(p.catalog_code), p.id])
    ),
    byBarcode = new Map(aliases.map(b => [b.barcode, b.product_id]));
  const result = parsed.map(r => {
    const barcode = byBarcode.get(r.barcode),
      code = byCode.get(key(r.code));
    return {
      ...r,
      status:
        code && code !== barcode ? "CONFLICT" : barcode ? "EXISTS" : "NEW",
      existingId: barcode ?? code ?? null,
    } as CatalogPreview["rows"][number];
  });
  const added = result.filter(r => r.status === "NEW").length,
    total = parsed.reduce((n, r) => n + BigInt(r.sourceQuantity), 0n);
  if (
    total > BigInt(Number.MAX_SAFE_INTEGER) ||
    total < BigInt(Number.MIN_SAFE_INTEGER)
  )
    fail("INVALID_CATALOG", "Kaynak miktar toplamı güvenli sınırı aşıyor.");
  return {
    hash: hash({ sourceHash, existing, aliases }),
    sourceHash,
    alreadyImported: !!prior,
    added,
    skipped: result.filter(r => r.status === "EXISTS").length,
    conflicts: result.filter(r => r.status === "CONFLICT").length,
    negativeRows: parsed.filter(r => r.sourceQuantity < 0).length,
    sourceTotalQty: Number(total),
    capacityExceeded: existing.length + added > 5000,
    rows: result,
  };
}
export function registerCatalogImport(
  app: Express,
  services: Services,
  post: MarketPost
) {
  app.post(
    "/api/stationos/market-accounting/inventory/catalog-preview",
    async (req, res) => {
      try {
        const actor = services.actor(req);
        services.assertMutation(req, actor);
        const station = requireId(req.body?.stationId, "stationId");
        res.json(
          await withTransaction(async c => {
            await services.requireStation(c, actor, station, READ);
            return preview(c, station, req.body?.text);
          })
        );
      } catch (e) {
        services.error(res, e);
      }
    }
  );
  app.get(
    "/api/stationos/market-accounting/inventory/catalog-history",
    async (req, res) => {
      try {
        const actor = services.actor(req),
          station = requireId(req.query.stationId, "stationId");
        res.json(
          await withTransaction(async c => {
            await services.requireStation(c, actor, station, READ);
            const imports = await rows<Row[]>(
              c,
              "SELECT i.*,u.name AS actor_name FROM st_catalog_imports i JOIN users u ON u.id=i.created_by_user_id WHERE i.station_id=? ORDER BY i.created_at DESC,i.id DESC LIMIT 20",
              [station]
            );
            return imports.map(i => {
              const source =
                typeof i.source_rows_json === "string"
                  ? JSON.parse(i.source_rows_json)
                  : i.source_rows_json;
              return {
                id: i.id,
                label: i.source_label,
                added: integer(i.added_count),
                skipped: integer(i.skipped_count),
                rows: source.length,
                negativeRows: source.filter((r: any) => r.sourceQuantity < 0)
                  .length,
                sourceTotalQty: Number(
                  source.reduce(
                    (n: bigint, r: any) => n + BigInt(r.sourceQuantity),
                    0n
                  )
                ),
                createdAt: i.created_at,
                actorName: i.actor_name,
              } satisfies CatalogHistory;
            });
          })
        );
      } catch (e) {
        services.error(res, e);
      }
    }
  );
  post(
    "inventory/catalog-import",
    WRITE,
    async (c, actor, body, scope, station, book) => {
      if (body.catalogOnlyAccepted !== true)
        fail(
          "CATALOG_POLICY_REQUIRED",
          "Yalnız yeni kart aktarımını ve kaynak stok/maliyetin işlenmeyeceğini teyit edin.",
          409
        );
      const label = requireString(body.label, "Liste adı", { max: 100 }),
      p = await preview(c, station, body.text, true);
      if (p.alreadyImported) {
        const old = (await first<Row>(
          c,
          "SELECT id,added_count,skipped_count FROM st_catalog_imports WHERE station_id=? AND source_hash=? FOR UPDATE",
          [station, p.sourceHash]
        ))!;
        return {
          id: old.id,
          added: integer(old.added_count),
          skipped: integer(old.skipped_count),
          alreadyImported: true,
        };
      }
      if (body.expectedHash !== p.hash)
        fail(
          "CATALOG_CHANGED",
          "Ürün kartları değişti; aktarım önizlemesini yenileyin.",
          409
        );
      if (p.conflicts)
        fail(
          "CATALOG_CONFLICT",
          "Stok kodu başka barkoda ait; çakışmaları çözün.",
          409
        );
      if (p.capacityExceeded)
        fail("SKU_LIMIT", "5.000 ürün kartı sınırı aşılır.", 409);
      const id = randomUUID(),
        stored = [];
      for (const r of p.rows) {
        if (r.status !== "NEW") {
          stored.push({ ...r, productId: r.existingId });
          continue;
        }
        const productId = randomUUID();
        await execute(
          c,
          "INSERT INTO st_products(id,tenant_id,station_id,name,barcode,minimum_qty,purchase_price_minor,sale_price_minor,supplier_id,created_by_user_id,category,base_unit,catalog_code) VALUES (?,?,?,?,?,0,0,?,NULL,?,?,?,?)",
          [
            productId,
            scope.tenantId,
            station,
            r.name,
            r.barcode,
            r.salePriceMinor,
            actor.id,
            r.category,
            r.unit,
            r.code,
          ]
        );
        await execute(
          c,
          "INSERT INTO st_product_barcodes(station_id,barcode,product_id,pack_qty,label) VALUES (?,?,?,1,'Ana barkod')",
          [station, r.barcode, productId]
        );
        if (book)
          await execute(
            c,
            "INSERT INTO st_market_inventory(product_id,station_id,quantity,value_minor) VALUES (?,?,0,0)",
            [productId, station]
          );
        stored.push({ ...r, productId });
      }
      await execute(
        c,
        "INSERT INTO st_catalog_imports(id,tenant_id,station_id,source_hash,source_label,added_count,skipped_count,source_rows_json,created_by_user_id) VALUES (?,?,?,?,?,?,?,?,?)",
        [
          id,
          scope.tenantId,
          station,
          p.sourceHash,
          label,
          p.added,
          p.skipped,
          JSON.stringify(stored),
          actor.id,
        ]
      );
      return { id, added: p.added, skipped: p.skipped, alreadyImported: false };
    },
    false,
    true
  );
}
