import { describe, it, expect } from "vitest";
import { parseCatalog, catalogHeaders } from "../../shared/catalog-import";
const header = catalogHeaders.join("\t");
const row = (qty = "-2", barcode = "001234567890", unit = "ADET") =>
  [
    "ST001",
    "Örnek ürün",
    barcode,
    "Gıda",
    qty,
    unit,
    "50,00",
    "20,40",
    "0",
  ].join("\t");
describe("catalog source parsing", () => {
  it("preserves a leading zero barcode and source deficit without posting cost", () => {
    expect(parseCatalog(header + "\n" + row())).toEqual([
      {
        line: 2,
        code: "ST001",
        name: "Örnek ürün",
        barcode: "001234567890",
        category: "Gıda",
        unit: "adet",
        sourceQuantity: -2,
        salePriceMinor: 5000,
        sourcePurchaseMinor: 2040,
        discountBps: 0,
      },
    ]);
  });
  it("accepts Unicode BOM, CRLF and quoted TSV cells", () => {
    const quoted = [
      "ST002",
      '"Adı ""özel"" ürün"',
      "8690000000001",
      "Gıda",
      "0",
      "ADET",
      "12,50",
      "0",
      "5,25",
    ].join("\t");
    expect(
      parseCatalog("\uFEFF" + header + "\r\n" + quoted + "\r\n")[0]
    ).toMatchObject({
      name: 'Adı "özel" ürün',
      discountBps: 525,
      salePriceMinor: 1250,
    });
  });
  it("rejects duplicates, noninteger quantities, unsupported units and malformed columns", () => {
    for (const text of [
      header + "\n" + row() + "\n" + row(),
      header + "\n" + row("-1,5"),
      header + "\n" + row("1", "0123456789", "KG"),
      header + "\n" + row() + "\textra",
      header + "\n" + row().replace("20,40", "-20,40"),
    ])
      expect(() => parseCatalog(text)).toThrow();
  });
  it("does not silently accept a different header, scientific notation or open quote", () => {
    for (const text of [
      header.replace("Stok Kodu", "Kod") + "\n" + row(),
      header + "\n" + row("1e3"),
      header + '\n"open',
    ])
      expect(() => parseCatalog(text)).toThrow();
  });
});
