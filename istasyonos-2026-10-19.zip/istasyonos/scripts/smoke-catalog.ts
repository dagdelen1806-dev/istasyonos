import { strict as assert } from "node:assert";
import { randomUUID, randomBytes } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import mysql from "mysql2/promise";
import { query, closeStationPool } from "../server/stationos/db";
import { payloadHash } from "../server/stationos/domain";
if (process.env.SMOKE_TEST !== "1")
  throw Error("Explicit opt-in required; synthetic DEMO writes only.");
const base = process.env.SMOKE_BASE_URL ?? "http://127.0.0.1:3303";
if (!["localhost", "127.0.0.1"].includes(new URL(base).hostname))
  throw Error("Local server required");
const db = new URL(process.env.DATABASE_URL ?? "");
if (
  db.pathname !== "/istasyonos_pos_v2_test" ||
  db.searchParams.get("socketPath") !== "/workspace/local-mysql/mysql.sock"
)
  throw Error("Exact isolated test DB required");
type Actor = {
  cookie: string;
  csrf: string;
  device: string;
  email: string;
  password: string;
};
async function http(path: string, a?: Actor, body?: Record<string, unknown>) {
  const r = await fetch(base + path, {
    method: body ? "POST" : "GET",
    headers: {
      "Content-Type": "application/json",
      "X-Stationos-Request": "1",
      Origin: base,
      ...(a
        ? {
            Cookie: a.cookie,
            "X-CSRF-Token": a.csrf,
            "X-Stationos-Device-Id": a.device,
          }
        : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  return {
    status: r.status,
    data: await r.json(),
    cookie: r.headers.get("set-cookie")?.split(";")[0] ?? "",
  };
}
async function auth(label: string) {
  const a: Actor = {
    cookie: "",
    csrf: "",
    device: randomUUID(),
    email: `market-${randomUUID()}@example.invalid`,
    password: randomBytes(24).toString("hex"),
  };
  const r = await http("/api/auth/register", undefined, {
    email: a.email,
    password: a.password,
    name: `DEMO ${label}`,
  });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  a.cookie = r.cookie;
  a.csrf = (await http("/api/stationos/state", a)).data.csrfToken;
  return a;
}
const owner = await auth("market sahibi"),
  manager = await auth("market yöneticisi"),
  staff = await auth("market personeli"),
  outsider = await auth("dış kullanıcı");
async function raw(
  path: string,
  a = owner,
  body?: Record<string, unknown>,
  expected = 200
) {
  const r = await http("/api/stationos" + path, a, body);
  assert.equal(r.status, expected, `${path}: ${JSON.stringify(r.data)}`);
  return r.data;
}
const station = (
  await raw("/setup", owner, {
    requestId: randomUUID(),
    companyName: `DEMO katalog testi ${randomUUID().slice(0, 8)}`,
    stationName: "DEMO Muhasebe Market",
    stationCode: randomUUID().slice(0, 8),
    isDemo: true,
  })
).result.stationId;
const post = (
  path: string,
  body: Record<string, unknown>,
  expected = 200,
  a = owner
) =>
  raw(
    path,
    a,
    { stationId: station, requestId: randomUUID(), ...body },
    expected
  ).then(d => d.result ?? d);
const prefix = "/market-accounting/inventory/",
  account = () => raw("/market-accounting?stationId=" + station);
for (const [a, role] of [
  [staff, "MARKET_STAFF"],
  [manager, "MANAGER"],
] as const) {
  const code = (await post("/invite", { role, stationIds: [station] })).code;
  await raw("/join", a, { requestId: randomUUID(), code });
}
const { catalogHeaders } = await import("../shared/catalog-import");
const row = (
  code: string,
  barcode: string,
  qty = -2,
  name = "DEMO kaynak ürün"
) =>
  [
    code,
    name,
    barcode,
    "DEMO GRUP",
    String(qty),
    "ADET",
    "50,00",
    "20,40",
    "0",
  ].join("\t");
const existing = (
  await post("/product", {
    name: "DEMO korunacak mevcut fiyat",
    barcode: "88881111",
    minimumQty: 0,
    purchasePriceMinor: 0,
    salePriceMinor: 777,
    supplierId: null,
  })
).id;
const text =
  catalogHeaders.join("\t") +
  "\n" +
  [
    row("ST-T-1", "001234567890"),
    row("ST-T-2", "88881111"),
    row("ST-T-3", "8690000000001", -3),
  ].join("\n");
const inspect = (value = text, a = owner) =>
  raw(prefix + "catalog-preview", a, { stationId: station, text: value });
await raw(prefix + "catalog-preview", staff, { stationId: station, text }, 403);
await raw(
  prefix + "catalog-preview",
  outsider,
  { stationId: station, text },
  403
);
await raw(
  prefix + "catalog-preview",
  owner,
  { stationId: station, text: "başlık yok" },
  400
);
let p = await inspect();
assert.equal(p.added, 2);
assert.equal(p.skipped, 1);
assert.equal(p.negativeRows, 3);
assert.equal(p.sourceTotalQty, -7);
await post("/product", {
  name: "DEMO katalog sürüm değişimi",
  barcode: "99992222",
  minimumQty: 0,
  purchasePriceMinor: 0,
  salePriceMinor: 333,
  supplierId: null,
});
await raw(prefix+'catalog-preview',{...owner,csrf:''},{stationId:station,text},403);
const apply = (preview: any, extra: Record<string, unknown> = {}) => ({
  text,
  label: "DEMO kaynak liste",
  expectedHash: preview.hash,
  catalogOnlyAccepted: true,
  ...extra,
});
await post(prefix + "catalog-import", apply(p), 409);
p = await inspect();
await post(
  prefix + "catalog-import",
  apply(p, { catalogOnlyAccepted: false }),
  409
);
await post(prefix + "catalog-import", apply(p), 403, staff);
const before = await account();
const both = await Promise.all(
  [owner, manager].map(a =>
    raw(prefix + "catalog-import", a, {
      stationId: station,
      requestId: randomUUID(),
      ...apply(p),
    })
  )
);
assert.equal(both[0].result.id, both[1].result.id);
let state = await account();
assert.deepEqual(state.balances, before.balances);
assert.equal(state.stockValueMinor, before.stockValueMinor);
assert.equal(
  state.stock.find((x: any) => x.id === existing).salePriceMinor,
  777
);
const inventory = await raw(
  "/market-accounting/inventory?stationId=" + station
);
const item = inventory.items.find((x: any) => x.catalogCode === "ST-T-1");
assert.equal(item.barcode, "001234567890");
assert.equal(item.quantity, 0);
assert.equal(item.averageCostMinor, 0);
assert.equal(item.vatBps, null);
assert.equal(item.purchaseVatBps, null);
assert.equal(item.salePriceMinor, 5000);
assert.equal(item.category, "DEMO GRUP");
assert.equal(item.lotTracking, false);
const history = await raw(prefix + "catalog-history?stationId=" + station);
assert.equal(history.length, 1);
assert.equal(history[0].added, 2);
assert.equal(history[0].negativeRows, 3);
assert.equal(history[0].sourceTotalQty, -7);
assert.equal((await inspect()).alreadyImported, true);
const conflict =
  catalogHeaders.join("\t") + "\n" + row("ST-T-1", "1234567890123");
const cp = await inspect(conflict);
assert.equal(cp.conflicts, 1);
await post(prefix + "catalog-import", { ...apply(cp), text: conflict }, 409);
await post("/market-accounting/start", {
  openingStockAccepted: true,
  expectedInventoryMinor: (await account()).openingInventoryMinor,
  cashMinor: 0,
  bankMinor: 0,
  cardMinor: 0,
});
state = await account();
const saved = JSON.stringify({
  balances: state.balances,
  daily: state.daily,
  revision: state.revision,
});
const newText =
    catalogHeaders.join("\t") + "\n" + row("ST-T-4", "0022223333444", -1),
  np = await inspect(newText),
  request = {
    stationId: station,
    requestId: randomUUID(),
    ...apply(np),
    text: newText,
  };
const result = await raw(prefix + "catalog-import", owner, request);
assert.deepEqual(await raw(prefix + "catalog-import", owner, request), result);
state = await account();
assert.equal(
  JSON.stringify({
    balances: state.balances,
    daily: state.daily,
    revision: state.revision,
  }),
  saved
);
await post("/market-accounting/day-close", {
  expectedRevision: state.revision,
  countedCashMinor: 0,
});
const closed = await account();
const closedSnapshot = JSON.stringify(closed.dayCloses);
const closedText =
    catalogHeaders.join("\t") + "\n" + row("ST-T-5", "0022223333555", -1),
  closedPreview = await inspect(closedText);
await post(prefix + "catalog-import", {
  ...apply(closedPreview),
  text: closedText,
});
assert.equal((await account()).closedToday, true);
assert.equal(JSON.stringify((await account()).dayCloses), closedSnapshot);
const sql = await mysql.createConnection(process.env.DATABASE_URL!);
const [stored]: any = await sql.query(
  "SELECT source_rows_json FROM st_catalog_imports WHERE station_id=? ORDER BY created_at,id",
  [station]
);
const source =
  typeof stored[0].source_rows_json === "string"
    ? JSON.parse(stored[0].source_rows_json)
    : stored[0].source_rows_json;
assert.equal(source.find((r: any) => r.code === "ST-T-1").sourceQuantity, -2);
assert.equal(
  source.find((r: any) => r.code === "ST-T-1").sourcePurchaseMinor,
  2040
);
const [bad]: any = await sql.query(
  "SELECT id FROM st_products WHERE station_id=? AND catalog_code IS NOT NULL AND (stock_qty<>0 OR purchase_price_minor<>0 OR market_vat_bps IS NOT NULL)",
  [station]
);
assert.equal(bad.length, 0);
await sql.end();
const output = process.env.SMOKE_OUTPUT_DIR ?? "/workspace/catalog-test/dev";
await mkdir(output, { recursive: true, mode: 0o700 });
await writeFile(
  output + "/fixture.json",
  JSON.stringify({ owner, manager, staff, outsider, station }),
  { mode: 0o600 }
);
const checks = [
  "Sekmeli liste doğrulama, rol/tenant ve CSRF koruması",
  "Yeni kart, baştaki sıfır, kaynak stok kodu ve kategori",
  "Mevcut barkod fiyatı/stoğu değiştirilmedi",
  "Katalog değiştiğinde önizleme yenileme zorunluluğu",
  "Aynı listeyi iki aktör eşzamanlı aktardığında tek parti",
  "Stok kodu farklı barkod çakışması reddi",
  "Defter öncesi ve aktif defterde stok/maliyet/bakiye değişmedi",
  "Kaynak eksi miktar ve alış fiyatı JSON kaynak kaydında korundu",
  "Aynı-ID tekrar ve kapalı gün sonrası yalnız sıfır stoklu yeni kart",
  "KDV/lot/SKT ve net maliyet tahmin edilmedi",
];
await writeFile(
  output + "/result.json",
  JSON.stringify({ ok: true, checks }, null, 2)
);
console.log(JSON.stringify({ ok: true, checks }, null, 2));
