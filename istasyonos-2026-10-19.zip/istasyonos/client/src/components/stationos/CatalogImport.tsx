import { useEffect, useRef, useState } from "react";
import { FileUp, RefreshCw, FileDown } from "lucide-react";
import { money } from "@shared/station";
import {
  parseCatalog,
  catalogHeaders,
  type CatalogPreview,
  type CatalogHistory,
} from "@shared/catalog-import";
import { previewCatalog, loadCatalogHistory } from "@/lib/station-api";
import { marketCsv } from "./MarketStatement";
export function CatalogImport({
  stationId,
  csrfToken,
  locked,
  canWrite,
  action,
}: {
  stationId: string;
  csrfToken: string | undefined;
  locked: boolean;
  canWrite: boolean;
  action: (path: string, body: Record<string, unknown>) => Promise<boolean>;
}) {
  const [text, setText] = useState(""),
    [label, setLabel] = useState("Stok listesi"),
    [preview, setPreview] = useState<CatalogPreview | null>(null),
    [history, setHistory] = useState<CatalogHistory[]>([]),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [accepted, setAccepted] = useState(false);
  const seq = useRef(0);
  const update = (value: string) => {
    seq.current++;
    setText(value);
    setPreview(null);
    setAccepted(false);
    setError("");
    setNotice("");
  };
  async function historyLoad() {
    setHistory(await loadCatalogHistory(stationId));
  }
  useEffect(() => {
    void historyLoad().catch(e => setError(e.message));
    return () => {
      seq.current++;
    };
  }, [stationId]);
  async function inspect() {
    const id = ++seq.current;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      parseCatalog(text);
      const result = await previewCatalog(stationId, text, csrfToken);
      if (id === seq.current) {
        setPreview(result);
        setAccepted(false);
      }
    } catch (e) {
      if (id === seq.current) {
        setPreview(null);
        setError((e as Error).message);
      }
    } finally {
      if (id === seq.current) setBusy(false);
    }
  }
  return (
    <section className="ma-panel">
      <div className="ma-panel-head">
        <div>
          <h2>Ürün listesinden kart aktarımı</h2>
          <p>
            Barkod ve fiyatları alır; kaynak eksi stokları, belirsiz alış
            maliyetini veya cari bakiyeyi işlemez.
          </p>
        </div>
        <button
          className="btn"
          disabled={locked || busy}
          onClick={() => void historyLoad().catch(e => setError(e.message))}
        >
          <RefreshCw size={16} />
          Aktarım geçmişini yenile
        </button>
      </div>
      <div className="notice warning">
        Bu aktarım yalnız yeni ürün kartı açar. Yeni stok ve maliyet 0, KDV ve
        lot/SKT tanımsız başlar. Mevcut barkodlu ürünün fiyatı, stoğu ve geçmişi
        korunur. Kaynak miktar/alış fiyatı/iskonto, kaynak kayıt olarak
        saklanır.
      </div>
      <fieldset disabled={locked || busy}>
        <label>
          Liste adı
          <input
            aria-label="Aktarım liste adı"
            value={label}
            onChange={e => setLabel(e.target.value)}
            maxLength={100}
          />
        </label>
        <label className="mi-catalog-file">
          <FileUp size={16} />
          Stok metin dosyası
          <input
            aria-label="Stok metin dosyası"
            type="file"
            accept=".txt,.tsv,.csv,text/plain,text/tab-separated-values"
            onChange={async e => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                if (f.size > 2100000)
                  throw Error("Dosya 2 MB sınırını aşıyor.");
                const bytes = new Uint8Array(await f.arrayBuffer()),
                  encoding =
                    bytes[0] === 255 && bytes[1] === 254
                      ? "utf-16le"
                      : bytes[0] === 254 && bytes[1] === 255
                        ? "utf-16be"
                        : "utf-8";
                const value = new TextDecoder(encoding, { fatal: true }).decode(
                  bytes
                );
                update(value);
                setLabel(f.name.slice(0, 100));
              } catch (error) {
                setError((error as Error).message);
              }
            }}
          />
        </label>
        <label>
          Başlık dahil stok listesini yapıştır
          <textarea
            aria-label="Stok listesi metni"
            rows={8}
            maxLength={1000000}
            value={text}
            onChange={e => update(e.target.value)}
            placeholder={catalogHeaders.join("\t")}
          />
        </label>
        <p className="ma-hint">
          Sekmeyle ayrılmış 9 sütun; en fazla 5.000 ADET ürün. UTF-8 veya
          Unicode metin kullanılabilir. Barkodlar metin olarak alınır; baştaki
          sıfırlar korunur. Satış Fiyatı 1 aynen satış fiyatına kopyalanır; KDV
          tahmin edilmez. Alış fiyatı kaynak bilgidir, net maliyet kabul
          edilmez; iskonto uygulanmaz.
        </p>
        <button
          className="btn primary"
          disabled={!text.trim()}
          onClick={() => void inspect()}
        >
          Listeyi kontrol et
        </button>
      </fieldset>
      {error && (
        <p role="alert" className="ma-error">
          {error}
        </p>
      )}
      {notice && (
        <p role="status" className="notice">
          {notice}
        </p>
      )}
      {busy && <p role="status">Liste kontrol ediliyor…</p>}
      {preview && (
        <>
          <div className="ma-wallet-grid">
            <div>
              <span>Kaynak ürün</span>
              <strong>{preview.rows.length}</strong>
            </div>
            <div>
              <span>Yeni / mevcut</span>
              <strong>
                {preview.added} / {preview.skipped}
              </strong>
            </div>
            <div>
              <span>Eksi stoklu satır</span>
              <strong>{preview.negativeRows}</strong>
            </div>
            <div>
              <span>Kaynak miktar toplamı · işlenmez</span>
              <strong>{preview.sourceTotalQty}</strong>
            </div>
          </div>
          {preview.alreadyImported && (
            <p className="notice">
              Bu listenin aynı içeriği daha önce aktarıldı; yeniden ürün
              oluşturulmaz.
            </p>
          )}
          {preview.conflicts > 0 && (
            <p className="ma-error">
              {preview.conflicts} stok kodu başka barkodla çakışıyor. Listeyi
              düzeltip yeniden kontrol edin.
            </p>
          )}
          {preview.capacityExceeded && (
            <p className="ma-error">5.000 ürün kartı sınırı aşılacak.</p>
          )}
          <div className="ma-table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Stok kodu / ürün</th>
                  <th>Barkod / grup</th>
                  <th>Kaynak stok</th>
                  <th>Satış fiyatı</th>
                  <th>Kaynak alış · KDV türü belirsiz</th>
                  <th>Sonuç</th>
                </tr>
              </thead>
              <tbody>
                {preview.rows.slice(0, 100).map(r => (
                  <tr key={r.line}>
                    <td>
                      <b>{r.code}</b>
                      <small>{r.name}</small>
                    </td>
                    <td>
                      {r.barcode}
                      <small>{r.category}</small>
                    </td>
                    <td className={r.sourceQuantity < 0 ? "ma-error" : ""}>
                      {r.sourceQuantity}
                    </td>
                    <td>{money(r.salePriceMinor)}</td>
                    <td>{money(r.sourcePurchaseMinor)}</td>
                    <td>
                      {r.status === "NEW"
                        ? "Yeni kart · stok 0"
                        : r.status === "EXISTS"
                          ? "Mevcut · değiştirilmez"
                          : "Kod çakışması"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="ma-hint">
            İlk 100 satır gösterilir; aktarım ve önizleme CSV'si tüm satırları
            içerir.
          </p>
          <button
            className="btn"
            onClick={() =>
              marketCsv("urun-aktarim-onizleme.csv", [
                [
                  "Stok kodu",
                  "Ad",
                  "Barkod",
                  "Grup",
                  "Kaynak stok",
                  "Yeni kart stoğu",
                  "Satış TL",
                  "Kaynak alış TL",
                  "Kaynak iskonto %",
                  "Durum",
                ],
                ...preview.rows.map(r => [
                  r.code,
                  r.name,
                  r.barcode,
                  r.category,
                  r.sourceQuantity,
                  r.status === "NEW" ? 0 : "Değişmez",
                  r.salePriceMinor / 100,
                  r.sourcePurchaseMinor / 100,
                  r.discountBps / 100,
                  r.status,
                ]),
              ])
            }
          >
            <FileDown size={16} />
            Önizlemeyi CSV indir
          </button>
          <label className="ma-check">
            <input
              aria-label="Yalnız kart aktarımını teyit et"
              type="checkbox"
              checked={accepted}
              disabled={locked || busy || !canWrite}
              onChange={e => setAccepted(e.target.checked)}
            />
            Yalnız yeni kartlar açılacak; kaynak miktar, alış maliyeti, iskonto
            ve bakiyeler işlenmeyecek.
          </label>
          <button
            className="btn primary"
            disabled={
              locked ||
              busy ||
              !canWrite ||
              !accepted ||
              !label.trim() ||
              preview.alreadyImported ||
              !!preview.conflicts ||
              preview.capacityExceeded ||
              !preview.added
            }
            onClick={async () => {
              if (
                await action("/market-accounting/inventory/catalog-import", {
                  text,
                  label,
                  expectedHash: preview.hash,
                  catalogOnlyAccepted: true,
                })
              ) {
                setNotice(
                  `${preview.added} ürün kartı eklendi; ${preview.skipped} mevcut ürün korundu. Stok ve mali defter değişmedi.`
                );
                setPreview({ ...preview, alreadyImported: true });
                setAccepted(false);
                await historyLoad().catch(e => setError(e.message));
              }
            }}
          >
            Yeni ürün kartlarını aktar
          </button>
        </>
      )}
      <h3>Son 20 liste aktarımı</h3>
      <div className="ma-table-wrap">
        <table>
          <thead>
            <tr>
              <th>Liste / tarih UTC</th>
              <th>Eklenen / korunan</th>
              <th>Kaynak eksi satır / toplam</th>
              <th>Kullanıcı</th>
            </tr>
          </thead>
          <tbody>
            {history.map(h => (
              <tr key={h.id}>
                <td>
                  {h.label}
                  <small>{h.createdAt}</small>
                </td>
                <td>
                  {h.added} / {h.skipped}
                </td>
                <td>
                  {h.negativeRows} / {h.sourceTotalQty}
                </td>
                <td>{h.actorName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="ma-hint">
        Eksi stok fizikî stok değildir; doğru miktar sayım veya belgeli mal
        kabul ile belirlenir. Sonraki satış için satış KDV'sini ve gerçek net
        maliyeti ayrıca doğrulayın. Liste işletmeye ait fiyat bilgileri içerir;
        herkese açık kaynak paketine eklenmez.
      </p>
    </section>
  );
}
