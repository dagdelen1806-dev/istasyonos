# İstasyonOS kaynak paketi — 19 Ekim 2026

Güncel çalışma klasörünün kaynak kopyasıdır. Lot/SKT/FEFO, karantina, parti sayımı/fire ve yalnız yeni ürün kartı aktarımı içerir. Paket hazır EXE değildir. Manus olmadan yerel e-posta/parola girişi desteklenir.

## Windows / mevcut Laragon kurulumu

1. Mevcut proje klasörünüzü ve MySQL veritabanınızı yedekleyin.
2. Arşivi açın; içindeki `istasyonos` klasörünü VS Code ile açın. Mevcut `.env` dosyanızı koruyun; paket `.env` içermez.
3. Laragon MySQL açıkken, proje terminalinde aşağıdaki komutları çalıştırın (Node 22/24, pnpm 10.18.0):

```powershell
pnpm install --frozen-lockfile
pnpm tsx server/stationos/migrate.ts
pnpm dev
```

Mevcut kurulumda operasyon göçleri 0015'e kadar uygulanır. Yeni/boş veritabanı kurulumu için `WINDOWS-BASLANGIC.md` ve `README.md` dosyalarını okuyun; kullanıcı tabloları için ayrıca `pnpm db:migrate` gerekir. Laragon ile Docker zorunlu değildir. `pnpm dev` çalışırken ikinci kez başlatmayın.

Tarayıcı: http://localhost:3000. `istasyonos.test` yönlendirmesi Windows/Laragon yapılandırmanıza bağlıdır; arşiv bunu otomatik kurmaz.

## Bu sürümün sınırı

`Market muhasebe > Ürün aktarımı` kaynak stok kodunu, barkodu, grubu ve satış fiyatını yeni karta alır. Mevcut barkodlu kartları değiştirmez; yeni kart stoğu ve maliyeti sıfırdır, KDV ayrıca tanımlanır. Kaynak eksi miktar ve alış fiyatı yalnız denetim kaydı olarak saklanır.

İstenen artı DEMO başlangıç stoğu ve grup bazlı KDV otomasyonu henüz tamamlanmadı. GIDA %1, İÇECEK %10, KİŞİSEL BAKIM/Araç bakımı %20 kullanıcı tercihi olarak not edildi; bu paket otomatik vergi eşlemesi yapmaz. Gerçek işletme stok/maliyeti fizikî sayım ve belgeli mal kabul ile doğrulanmalıdır.

Lot/SKT kullanımı için `docs/market-lot-skt-2026-10-17.md` dosyasını okuyun. Gerçek banka, mali fiş/e-belge, ÖKC ve çevrimdışı tarayıcı satışı bu teslimde yoktur.

## Kontrol ve gizlilik

19 Ekim 2026: TypeScript kontrolü, 14 dosyada 65 test ve üretim derlemesi başarılı. Eski dokümanlardaki sayılar ilgili tarihteki sonuçlardır. Fiziksel Windows cihazları bu ortamda denenmedi.

`.env`, parolalar, kullanıcı ürün/fiyat listesi, veritabanı, `.git`, `node_modules` ve `dist` içermez. Bağımlılıklar lockfile üzerinden kurulur. `DOSYA-MANIFESTI.json` manifest kendisi hariç her dosyanın SHA-256 değerini içerir.
